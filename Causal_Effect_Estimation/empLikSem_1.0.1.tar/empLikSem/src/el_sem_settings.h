#ifndef EL_SEM_SETTING_H
#define EL_SEM_SETTING_H

static const double BACKTRACKING_SCALING_CONST = .2;
static const int INFEASIBLE_RETURN = 100000000;


#endif
