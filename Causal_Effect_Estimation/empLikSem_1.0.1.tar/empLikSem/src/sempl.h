#ifndef SEMPL_H
#define SEMPL_H


#include <stdlib.h>
#include <math.h>
#include <RcppArmadillo.h>
#include "elSEM.h"
#include "elSEM_naive.h"

using namespace Rcpp ;
using namespace arma;



#endif

